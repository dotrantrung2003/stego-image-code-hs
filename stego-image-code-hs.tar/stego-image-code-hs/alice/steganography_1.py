import numpy as np
import sys

matrix_path = sys.argv[1] #new_gray_matrix
matrix = np.loadtxt(matrix_path, dtype=np.int32)

values = matrix.flatten()

peak = int(sys.argv[2]) #49
quantity = int(sys.argv[3]) #32

indices = np.where(values == peak)[0]

selected_indices = indices[:quantity]

selected_values = values[selected_indices]

with open("steganography.txt", "w") as f:
    f.write(" ".join(map(str, selected_values)) + "\n")

print(f"The first {quantity} pixels have a value of {peak} have been saved in steganography.txt")
