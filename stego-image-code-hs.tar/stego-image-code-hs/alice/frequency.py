import numpy as np
from collections import Counter
import sys

matrix_path = sys.argv[1]
matrix = np.loadtxt(matrix_path, dtype=np.int32)

values = matrix.flatten()

counter = Counter(values)

full_counter = {i: counter.get(i, 0) for i in range(256)}

sorted_items = sorted(full_counter.items(), key=lambda x: (-x[1], x[0]))

with open("frequency.txt", "w") as f:
    for value, freq in sorted_items:
        f.write(f"{value}: {freq}\n")

print("Frequency of pixel brightness values has been saved in frequency.txt")