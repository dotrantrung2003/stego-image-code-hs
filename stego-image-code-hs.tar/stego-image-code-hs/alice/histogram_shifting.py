import numpy as np
import sys

matrix_path = sys.argv[1]
peak = int(sys.argv[2]) #49
zero = int(sys.argv[3]) #254


gray_matrix = np.loadtxt(matrix_path, dtype=np.int32)

modified_matrix = gray_matrix.copy()

modified_matrix[(modified_matrix > peak) & (modified_matrix < zero)] += 1

np.savetxt("new_gray_matrix.txt", modified_matrix, fmt="%d")

print("New gray matrix has been saved in new_gray_matrix.txt")