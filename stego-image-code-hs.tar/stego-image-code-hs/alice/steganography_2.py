import numpy as np
import sys

matrix_path = sys.argv[1] #new_gray_matrix
matrix = np.loadtxt(matrix_path, dtype=np.int32)

with open("steganography.txt", "r") as f:
    new_values = list(map(int, f.read().split()))

peak = int(sys.argv[2]) #49

values = matrix.flatten()

indices = np.where(values == peak)[0]

if len(indices) >= len(new_values):
    
    values[indices[:len(new_values)]] = new_values

    new_matrix = values.reshape(matrix.shape)

    np.savetxt("new_gray_matrix.txt", new_matrix, fmt="%d")

    print("New gray matrix has been saved in new_gray_matrix.txt")
else:
    print("Error")
