import sys

binary_text= sys.argv[1]

for i in range(0, len(binary_text), 8):
    tmp = int(binary_text[i:i+8], 2)
    print(chr(tmp), end="")
print("")
