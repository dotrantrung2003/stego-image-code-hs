import numpy as np
import sys

matrix_path = sys.argv[1] #new_gray_matrix
matrix = np.loadtxt(matrix_path, dtype=np.int32)

values = matrix.flatten()

a = int(sys.argv[2]) #49
b = int(sys.argv[3]) #50
quantity = int(sys.argv[4]) #32

a_indices = np.where(values == a)[0]
b_indices = np.where(values == b)[0]

indices = sorted(list(a_indices) + list(b_indices))
selected_indices = indices[:quantity]

selected_values = values[selected_indices]

with open("desteganography.txt", "w") as f:
    f.write(" ".join(map(str, selected_values)) + "\n")

print(f"The first {quantity} pixels have a value of {a} of {b} have been saved in desteganography.txt")
